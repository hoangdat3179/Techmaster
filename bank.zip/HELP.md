[{
	"resource": "/Users/cuong/CODE/SpringBoot7/09-Bank/bank",
	"owner": "_generated_diagnostic_collection_name_#4",
	"code": "964",
	"severity": 8,
	"message": "The container 'Maven Dependencies' references non existing library '/Users/cuong/.m2/repository/org/assertj/assertj-core/3.18.1/assertj-core-3.18.1.jar'",
	"source": "Java",
	"startLineNumber": 1,
	"startColumn": 1,
	"endLineNumber": 1,
	"endColumn": 1
}]