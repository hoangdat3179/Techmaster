package vn.techmaster.bank;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import vn.techmaster.bank.model.Bank;

@Component
public class AppRunner implements CommandLineRunner{
  @Autowired private EntityManager em;
  @Override
  public void run(String... args) throws Exception {
    
    
  }

  private void generateSomeBanks() {
    Bank vietcombank = new Bank("vcb", :)
  }
  
}
