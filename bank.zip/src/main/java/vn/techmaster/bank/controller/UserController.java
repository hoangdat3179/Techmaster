package vn.techmaster.bank.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
  
}
