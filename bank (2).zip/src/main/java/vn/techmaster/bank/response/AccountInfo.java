package vn.techmaster.bank.response;


public record AccountInfo (String accountid, String bank_name, Long amount) {
  
}
