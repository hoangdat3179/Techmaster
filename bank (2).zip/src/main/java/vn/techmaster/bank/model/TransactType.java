package vn.techmaster.bank.model;

public enum TransactType {
  TRANSFER,
  DEPOSIT,
  WITHDRAW
}
