package vn.techmaster.bank.model;

public enum CommandStatus {
  SUCCESS,
  FAILED,
  CANCELLED
}
