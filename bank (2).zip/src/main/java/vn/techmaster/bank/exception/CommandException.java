package vn.techmaster.bank.exception;

public class CommandException extends RuntimeException {

  public CommandException(String arg0) {
    super(arg0);
  }
  
}
