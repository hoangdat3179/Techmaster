insert into users (id, name, mobile, email) values ('0001', 'bob', '0902209073', 'bob@mgmail.com');
insert into users (id, name, mobile, email) values ('0002', 'alice', '09022097899', 'alice@mgmail.com');
insert into users (id, name, mobile, email) values ('0003', 'tom', '07033097899', 'tom@mgmail.com');
insert into users (id, name, mobile, email) values ('0004', 'sara', '05024297801', 'sara@mgmail.com');