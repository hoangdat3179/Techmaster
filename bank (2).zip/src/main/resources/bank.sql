insert into bank (id, name) values ('vcb', 'Vietcombank');
insert into bank (id, name) values ('acb', 'Ngân hàng Á Châu');
insert into bank (id, name) values ('bidv', 'Đầu tư phát triển Việt nam');
insert into bank (id, name) values ('vp', 'Việt nam Thịnh Vượng');
insert into bank (id, name) values ('tcb', 'Kỹ thương Việt nam');